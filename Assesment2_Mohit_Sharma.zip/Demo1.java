package assesmentJava;

import java.util.Scanner;

class Operations {

	String str = "The quick brown FOX jumps over the lazy dog";
	private Scanner sc;

	public void display() {
		System.out.println("\nThe current string : " + str + "\n");
		int ch;
		sc = new Scanner(System.in);

		System.out.println("MENU\n\nSelect choice from (1 to 15):\n\n"
				+ "1.	Print the character at the 12th index. \r\n"
				+ "2.	Check whether the String contains the word “is”. \r\n"
				+ "3.	Add the string “and killed it” to the existing string. \r\n"
				+ "4.	Check whether the String ends with the word “dogs”. \r\n"
				+ "5.	Check whether the String is equal to “The quick brown Fox jumps over the lazy Dog”.\r\n"
				+ "6.	Check whether the String is equal to “THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG”.\r\n"
				+ "7.	Find the length of the String. \r\n"
				+ "8.	Check whether the String matches to “The quick brown Fox jumps over the lazy Dog”. \r\n"
				+ "9.	Replace the word “The” with the word “A”. \r\n"
				+ "10.	Split the above string into two such that two animal names do not come together. \r\n"
				+ "11.	Print the animal names alone separately from the above string. \r\n"
				+ "12.	Print the above string in completely lower case. \r\n"
				+ "13.	Print the above string in completely upper case.\r\n"
				+ "14.	Find the index position of the character “a”. \r\n"
				+ "15.	Find the last index position of the character “e”. \r\n" + "0. Exit \r\n" + "Enter choice : ");
		ch = sc.nextInt();
		switch (ch) {

		case 0:
			System.out.println("Program Over");
			break;
		case 1:
			System.out.println("1.	Print the character at the 12th index. \r\n");
			function1();
			break;

		case 2:
			System.out.println("2.	Check whether the String contains the word 'is'. \r\n");
			function2();
			break;

		case 3:
			System.out.println("3.	Add the string 'and killed it' to the existing string. \r\n");
			function3();
			break;

		case 4:
			System.out.println("4.	Check whether the String ends with the word 'dogs'. \r\n");
			function4();
			break;

		case 5:
			System.out.println(
					"5.	Check whether the String is equal to 'The quick brown Fox jumps over the lazy Dog'.\r\n");
			function5();
			break;

		case 6:
			System.out.println(
					"6.	Check whether the String is equal to 'THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG'. \r\n");
			function6();
			break;

		case 7:
			System.out.println("7.	Find the length of the String. \r\n");
			function7();
			break;

		case 8:
			System.out.println(
					"8.	Check whether the String matches to 'The quick brown Fox jumps over the lazy Dog'.\r\n");
			function8();
			break;

		case 9:
			System.out.println("9.	Replace the word 'The' with the word 'A'. \r\n");
			function9();
			break;

		case 10:
			System.out.println(
					"10.	Split the above string into two such that two animal names do not come together. \r\n");
			function10();
			break;

		case 11:
			System.out.println("11.	Print the animal names alone separately from the above string. \r\n");
			function11();
			break;

		case 12:
			System.out.println("12.	Print the above string in completely lower case. \r\n");
			function12();
			break;

		case 13:
			System.out.println("13.	Print the above string in completely upper case.\r\n");
			function13();
			break;

		case 14:
			System.out.println("14.	Find the index position of the character “a”. \r\n");
			function14();
			break;

		case 15:
			System.out.println("15.	Find the last index position of the character “e”. \r\n" + "");
			function15();
			break;

		default:
			System.out.println("Wrong option selected, select choice (1 to 15)");
			break;
		}
		System.out.println();
	}

	public void function1() {

		char ch = str.charAt(12);
		System.out.println(ch);
	}

	public void function2() {

		if (str.contains("is"))
			System.out.println("\nThe given string contains the word 'is'");
		else
			System.out.println("\nThe given string does not contain the word 'is'");
	}

	public void function3() {
		// String str1;
		str = str.concat(" and killed it");
		System.out.println("\n" + str);
	}

	public void function4() {
		if (str.endsWith("dogs"))
			System.out.println("\nThe string ends with the word 'dogs'");
		else
			System.out.println("\nThe string does not end with the word 'dogs'");
	}

	public void function6() {
		if (str.equals("\nThe quick brown Fox jumps over the lazy Dog"))
			System.out.println("\nThe given string is equal to 'The quick brown Fox jumps over the lazy Dog'");
		else
			System.out.println("\nStrings are unequal");
	}

	public void function5() {
		if (str.equals("\nTHE QUICK BROWN FOX JUMPS OVER THE LAZY DOG"))
			System.out.println("\nThe given string is equal to 'THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG'");
		else
			System.out.println("\nStrings are unequal");
	}

	public void function7() {
		System.out.println("\nThe length of the given string is: " + str.length());
	}

	public void function8() {
		if (str.equalsIgnoreCase("The quick brown Fox jumps over the lazy Dog"))
			System.out.println("\nThe given string matches 'The quick brown Fox jumps over the lazy Dog'");
	}

	public void function9() {
		str = str.replaceAll("The", "a");
		System.out.println("\nAll words 'The' replaced with 'a' in the given string");
		System.out.println("\n" + str);
	}

	public void function10() {
		System.out.println("N.A.");
	}

	public void function11() {
		if (str.contains("fox") == true && str.contains("dog") == false)
			System.out.println("\nThe animal names from the given string are : fox");

		else if (str.contains("dog") == true && str.contains("fox") == false)
			System.out.println("\nThe animal names from the given string are : dog");

		else if (str.contains("fox") == true && str.contains("dog") == true)
			System.out.println("\nThe animal names from the given string are : fox and dog");

		else if (str.contains("FOX") == true && str.contains("DOG") == false)
			System.out.println("\nThe animal names from the given string are : FOX");

		else if (str.contains("DOG") == true && str.contains("FOX") == false)
			System.out.println("\nThe animal names from the given string are : DOG");

		else if (str.contains("FOX") == true && str.contains("DOG") == true)
			System.out.println("\nThe animal names from the given string are : FOX and DOG");

	}

	public void function12() {
		str = str.toLowerCase();
		System.out.println("\n" + str);
	}

	public void function13() {
		str = str.toUpperCase();
		System.out.println("\n" + str);
	}

	public void function14() {
		int index1 = str.indexOf('a');
		System.out.println("\nThe index of 'a' in the given string is : " + index1);
	}

	public void function15() {
		int lastindex = str.lastIndexOf('e');
		System.out.println("\nThe last index of 'e' in the given string is : " + lastindex);
	}

}

public class Demo1 {

	private static Scanner scanner;

	public static void main(String[] args) {
		Operations obj = new Operations();
		scanner = new Scanner(System.in);
		char ans;
		do {
			obj.display();
			System.out.println("Do you want to continue ? [y,Y / n,N] : ");

			ans = scanner.next().charAt(0);
		} while (ans == 'y' || ans == 'Y');
	}
}
