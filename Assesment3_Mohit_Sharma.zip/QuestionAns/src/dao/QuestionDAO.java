package dao;

import model.Question;

public interface QuestionDAO {
	public Question getQuestion(int questionNo);
	public int[] getValue();
}
