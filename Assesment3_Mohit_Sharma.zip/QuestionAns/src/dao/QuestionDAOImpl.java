package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.DBconnection;
import model.Question;

public class QuestionDAOImpl implements QuestionDAO {
	Connection connection = DBconnection.getConnection();
	private static final String FETCH_QUESTION = "select* from questions where questionNo=?";
	@Override
	public Question getQuestion(int questionNo) {
		Question q = new Question();
		PreparedStatement statement;
		try {
			
			statement = connection.prepareStatement(FETCH_QUESTION);
			statement.setInt(1, questionNo);
			
			ResultSet res;
			res = statement.executeQuery();
			res.next();
			q.setQuestionNo(res.getInt(1));
			q.setQuestion(res.getString(2));
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return q;
	}
	@Override
	public int[] getValue() {
		int qarr[]=null;
		qarr = new int[3];
		for(int i=0;i<3;i++) {
			double rand = Math.random()*10;
			qarr[i]=1+ (int) Math.round(rand);
			
		}
		
		return qarr;
	}

}
