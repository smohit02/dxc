package com;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.QuestionDAO;
import dao.QuestionDAOImpl;
import model.Question;

/**
 * Servlet implementation class Q1NAV
 */
public class Q2NAV extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Q2NAV() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session2=request.getSession(false); 
		int Q2=(int) session2.getAttribute("q2name");  
        QuestionDAO productDAO=new QuestionDAOImpl();
        Question Qno = productDAO.getQuestion(Q2);
		
		
		response.getWriter().println("<h2>"+Qno+"</h2>");
		request.setAttribute("view", Qno);
		request.getRequestDispatcher("display2.jsp").forward(request, response);
	}

}
