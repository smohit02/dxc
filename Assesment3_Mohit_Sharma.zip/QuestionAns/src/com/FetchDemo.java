package com;


import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.QuestionDAO;
import dao.QuestionDAOImpl;
import model.Question;



/**
 * Servlet implementation class FetchDemo
 */
public class FetchDemo extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FetchDemo() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		QuestionDAO productDAO=new QuestionDAOImpl();
		int[] arr2=productDAO.getValue();
		int q1=arr2[0];
		int q2=arr2[1];
		int q3=arr2[2];
		HttpSession session1=request.getSession();  
        session1.setAttribute("q1name",q1); 
		HttpSession session=request.getSession();  
        session.setAttribute("q2name",q2); 
        HttpSession session2=request.getSession();  
        session2.setAttribute("q3name",q3);
		Question Qno = productDAO.getQuestion(q1);
		request.getRequestDispatcher("Q1NAV").forward(request, response);
	}

}
