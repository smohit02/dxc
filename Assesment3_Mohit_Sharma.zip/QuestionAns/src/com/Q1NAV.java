package com;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.QuestionDAO;
import dao.QuestionDAOImpl;
import model.Question;

/**
 * Servlet implementation class QNAV
 */
public class Q1NAV extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Q1NAV() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	       HttpSession session1=request.getSession(false);  
	        int Q1=(int) session1.getAttribute("q1name");  
	        QuestionDAO productDAO=new QuestionDAOImpl();
	        Question Qno = productDAO.getQuestion(Q1);
			
			
			response.getWriter().println("<h2>"+Qno+"</h2>");
			request.setAttribute("view", Qno);
			request.getRequestDispatcher("display1.jsp").forward(request, response);
	        
	}

}
