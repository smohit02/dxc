package com.hms.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.hibernate.annotations.NamedQueries;
import org.hibernate.annotations.NamedQuery;

@NamedQueries({ @NamedQuery(name = "finddoctorName", query = "from Doctor d where d.doctorName=:docName") })

@Entity
public class Doctor {

	@Id
	private int DoctorId;

	@Column(name = "doctor Name")
	private String doctorName;

	@Column(name = "Doctor Fee")
	private int fees;

	@Column(name = "Hospital Details")
	private String HospitalName;
	
	@Column(name = "Hospital City")
	private String city;

	public int getDoctorId() {
		return DoctorId;
	}

	public void setDoctorId(int doctorId) {
		DoctorId = doctorId;
	}

	public String getdoctorName() {
		return doctorName;
	}

	public void setdoctorName(String doctorName) {
		doctorName = doctorName;
	}

	public int getFees() {
		return fees;
	}

	public void setFees(int fees) {
		this.fees = fees;
	}

	public String getHospitalName() {
		return HospitalName;
	}

	public void setHospitalName(String hospitalName) {
		HospitalName = hospitalName;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + DoctorId;
		result = prime * result + ((doctorName == null) ? 0 : doctorName.hashCode());
		result = prime * result + ((HospitalName == null) ? 0 : HospitalName.hashCode());
		result = prime * result + ((city == null) ? 0 : city.hashCode());
		result = prime * result + fees;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Doctor other = (Doctor) obj;
		if (DoctorId != other.DoctorId)
			return false;
		if (doctorName == null) {
			if (other.doctorName != null)
				return false;
		} else if (!doctorName.equals(other.doctorName))
			return false;
		if (HospitalName == null) {
			if (other.HospitalName != null)
				return false;
		} else if (!HospitalName.equals(other.HospitalName))
			return false;
		if (city == null) {
			if (other.city != null)
				return false;
		} else if (!city.equals(other.city))
			return false;
		if (fees != other.fees)
			return false;
		return true;
	}

	public Doctor(int doctorId, String doctorName, int fees, String hospitalName, String city) {
		super();
		this.DoctorId = doctorId;
		this.doctorName = doctorName;
		this.fees = fees;
		this.HospitalName = hospitalName;
		this.city = city;
	}

	public Doctor() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Doctor [DoctorId=" + DoctorId + ", doctorName=" + doctorName + ", fees=" + fees + ", HospitalName="
				+ HospitalName + ", city=" + city + "]";
	}

}
