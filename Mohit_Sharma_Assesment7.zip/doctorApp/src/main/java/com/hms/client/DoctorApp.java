package com.hms.client;

import java.util.List;
import java.util.Scanner;

import com.hms.DAO.DoctorDAO;
import com.hms.DAO.DoctorDAOImpl;
import com.hms.model.Doctor;

public class DoctorApp {

	DoctorDAO doctorDAO;
	int choice = 0;
	int doctorId;
	String doctorName;
	int docfee;
	String hospitalName;
	String city;
	Scanner scanner = new Scanner(System.in);

	public DoctorApp() {

		this.doctorDAO = new DoctorDAOImpl();

	}

	public void launchDoctorApp() {

		while (true) {
			System.out.println("M E N U ");
			System.out.println("1. Add The doctors : ");
			System.out.println("2. Get All The doctors : ");
			System.out.println("3. Get doctors by id : ");
			System.out.println("4. Get doctors by name : ");
			System.out.println("5. Delete profuct by id : ");
			System.out.println("6. Update doctor by id : ");
			System.out.println("7. E X I T");

			System.out.println("Please enter your choice : (1-6)");
			choice = scanner.nextInt();

			switch (choice) {
			case 1:
				Doctor doctor = takeDoctorInput();
				if (!doctorDAO.isDoctorExists(doctor.getDoctorId())) {
					doctorDAO.addDoctor(doctor);
				} else {
					System.out.println("Doctor already exists with doctor id : " + doctorId);
				}
				break;
			case 2:
				System.out.println(doctorDAO.getAllDoctors());
				break;
			case 3:
				System.out.println("Please enter doctor id to search :");
				doctorId = scanner.nextInt();
				if (doctorDAO.isDoctorExists(doctorId)) {
					Doctor searchedDoctor = doctorDAO.getDoctor(doctorId);
					System.out.println(searchedDoctor);
				} else {
					System.out.println("Doctor Id not found");
				}
				break;
			case 4:
				System.out.println("Please enter doctor name to search :");
				doctorName = scanner.next();
				
				List<Doctor> searchedDoctor = doctorDAO.getAllDoctors(doctorName);
				System.out.println(searchedDoctor);
				
				
//				if (doctorDAO.isDoctorNameExists(doctorName)) {
//					List<Doctor> searchedDoctor = doctorDAO.getAllDoctors(doctorName);
//					System.out.println(searchedDoctor);
//				} else {
//					System.out.println("Doctor Name not found");
//				}
				break;
			case 5:
				System.out.println("Please enter doctor id to delete :");
				doctorId = scanner.nextInt();
				if (doctorDAO.isDoctorExists(doctorId)) {
					doctorDAO.deleteDoctor(doctorId);
					System.out.println("Doctor deleted successfully");
				} else {
					System.out.println("Doctor Id not found");
				}
				break;
			case 6:
				System.out.println("Welcome to doctor app category : ");
				Doctor doctorToUpdate = takeDoctorInput();
				if (doctorDAO.isDoctorExists(doctorToUpdate.getDoctorId())) {
					doctorDAO.updateDoctor(doctorToUpdate);
					System.out.println("Your doctor updated successfully ");
				} else {
					System.out.println("Doctor id does not exists");
				}
				break;
			case 7:
				System.out.println("Thanks for using my app");
				System.exit(0);
			default:
				System.out.println(" Please enter (1-3)");
			}
		}
	}

	private Doctor takeDoctorInput() {
		System.out.println("Please enter doctor id :");
		doctorId = scanner.nextInt();
		System.out.println("Please enter doctor name :");
		doctorName = scanner.next();
		System.out.println("Please enter doctor fee :");
		docfee = scanner.nextInt();
		System.out.println("Please enter hospital name :");
		hospitalName = scanner.next();
		System.out.println("Please enter city :");
		city = scanner.next();

		Doctor doctor = new Doctor(doctorId, doctorName, docfee, hospitalName, city);
		return doctor;
		// TODO Auto-generated method stub

	}

}
