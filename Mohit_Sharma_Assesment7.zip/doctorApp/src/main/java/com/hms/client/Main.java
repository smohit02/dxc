package com.hms.client;

public class Main {

	public static void main(String[] args) {
		System.out.println("Hospital Management System for Doctor Data");
		DoctorApp app = new DoctorApp();
		app.launchDoctorApp();
}
}
