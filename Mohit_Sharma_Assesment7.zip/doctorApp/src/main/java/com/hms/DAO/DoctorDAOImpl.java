package com.hms.DAO;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.hms.model.Doctor;
import com.hms.util.HibernateUtil;

public class DoctorDAOImpl implements DoctorDAO {

	SessionFactory sf = HibernateUtil.getSessionFactory();

	public Doctor getDoctor(int DoctorId) {
		Session session = sf.openSession();
		Doctor product = (Doctor) session.get(Doctor.class, DoctorId);
		return product;
	}

	public List<Doctor> getAllDoctors() {
		Session session = sf.openSession();
		Query query = session.createQuery("from Doctor");
		return query.list();
	}

	public List<Doctor> getAllDoctors(String doctorName) {
		Session session = sf.openSession();
		Query query = session.getNamedQuery("finddoctorName");
		query.setString("docName", doctorName);
		return query.list();
	}

	public void addDoctor(Doctor doctor) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(doctor);
		transaction.commit();
		session.close();
		System.out.println("Added");
	}

	public void deleteDoctor(int DoctorId) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		Doctor doctor = new Doctor();
		doctor.setDoctorId(DoctorId);
		session.delete(doctor);
		transaction.commit();
		session.close();
	}

	public void updateDoctor(Doctor newDoctor) {
		Session session = sf.openSession();
		Transaction transaction = session.beginTransaction();
		Doctor oldDoctor = (Doctor) session.get(Doctor.class, newDoctor.getDoctorId());
		oldDoctor.setdoctorName(newDoctor.getdoctorName());
		oldDoctor.setFees(newDoctor.getFees());
		oldDoctor.setHospitalName(newDoctor.getHospitalName());
		oldDoctor.setCity(newDoctor.getCity());
		transaction.commit();
		session.close();
	}

	public boolean isDoctorExists(int DoctorId) {
		Session session = sf.openSession();
		Doctor doctor = (Doctor)session.get(Doctor.class, DoctorId);
		if (doctor == null)
			return false;
		else
			return true;

	}

	public boolean isDoctorNameExists(String doctorName) {
		Session session = sf.openSession();
		Doctor doctor = (Doctor) session.get(Doctor.class, doctorName);
		if (doctor == null)
			return false;
		else
			return true;
	}

}
