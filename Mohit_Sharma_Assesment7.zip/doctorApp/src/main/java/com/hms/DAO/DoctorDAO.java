package com.hms.DAO;

import java.util.List;

import com.hms.model.Doctor;


public interface DoctorDAO {
	public Doctor getDoctor(int DoctorId);
	public List<Doctor> getAllDoctors();
	public void addDoctor(Doctor doctor);
	public void deleteDoctor(int DoctorId);
	public void updateDoctor(Doctor doctor);
	public boolean isDoctorExists(int DoctorId);
	List<Doctor> getAllDoctors(String DoctorName);
	public boolean isDoctorNameExists(String doctorName);
}
